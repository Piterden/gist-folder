<?php namespace Defr\VersionControlExtension\Revision;

use Anomaly\Streams\Platform\Database\Seeder\Seeder;

class RevisionSeeder extends Seeder
{

    /**
     * Run the seeder.
     */
    public function run()
    {
        //
    }
}
