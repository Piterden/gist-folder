<?php

return [
    'title'       => 'Fixes',
    'name'        => 'Fixes Extension',
    'description' => ''
];
