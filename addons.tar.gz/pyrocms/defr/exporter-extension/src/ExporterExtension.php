<?php namespace Defr\ExporterExtension;

use Anomaly\Streams\Platform\Addon\Extension\Extension;

class ExporterExtension extends Extension
{

    /**
     * This extension provides...
     *
     * @var null|string
     */
    protected $provides = null;
}
