<?php

return [
    'migration_created' => 'Migration created successfully!',
    'migration_create_failed' => 'There is an error creating migration!',
];
