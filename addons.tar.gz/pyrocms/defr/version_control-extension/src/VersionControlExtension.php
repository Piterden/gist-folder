<?php namespace Defr\VersionControlExtension;

use Anomaly\Streams\Platform\Addon\Extension\Extension;

class VersionControlExtension extends Extension
{

    /**
     * This extension provides...
     *
     * @var null|string
     */
    protected $provides = null;
}
