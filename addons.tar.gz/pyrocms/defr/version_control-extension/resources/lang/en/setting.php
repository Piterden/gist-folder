<?php

return [
    'enabled_streams' => [
        'name' => 'Versionizing Enabled Streams',
    ],
];
