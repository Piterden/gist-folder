<?php

use Anomaly\Streams\Platform\Database\Migration\Migration;

class AnomalyModulePostsCreatePostsFields extends Migration
{

    /**
     * The addon fields.
     *
     * @var array
     */
    protected $fields = [
        'author' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.relationship',
            'config' => [
                'mode' => 'lookup',
                'related' => 'Anomaly\UsersModule\User\UserModel',
            ],
        ],
        'category' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.relationship',
            'config' => [
                'related' => 'Anomaly\PostsModule\Category\CategoryModel',
            ],
        ],
        'content' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.wysiwyg',
            'config' => [
            ],
        ],
        'description' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.textarea',
            'config' => [
            ],
        ],
        'enabled' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.boolean',
            'config' => [
                'default_value' => '',
            ],
        ],
        'entry' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.polymorphic',
            'config' => [
            ],
        ],
        'featured' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.boolean',
            'config' => [
                'default_value' => '',
            ],
        ],
        'layout' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.editor',
            'config' => [
                'default_value' => '{{ post.content|raw }}',
                'mode' => 'twig',
            ],
        ],
        'meta_description' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.textarea',
            'config' => [
            ],
        ],
        'meta_keywords' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.tags',
            'config' => [
            ],
        ],
        'meta_title' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.text',
            'config' => [
            ],
        ],
        'name' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.text',
            'config' => [
            ],
        ],
        'publish_at' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.datetime',
            'config' => [
            ],
        ],
        'slug' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.slug',
            'config' => [
                'slugify' => 'title',
                'type' => '-',
            ],
        ],
        'str_id' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.text',
            'config' => [
            ],
        ],
        'summary' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.textarea',
            'config' => [
            ],
        ],
        'tags' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.tags',
            'config' => [
            ],
        ],
        'theme_layout' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.select',
            'config' => [
                'handler' => 'Anomaly\SelectFieldType\Handler\Layouts',
            ],
        ],
        'title' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.text',
            'config' => [
            ],
        ],
        'ttl' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.integer',
            'config' => [
                'min' => '0',
                'step' => '1',
                'page' => '5',
            ],
        ],
        'type' => [
            'namespace' => 'posts',
            'type' => 'anomaly.field_type.relationship',
            'config' => [
                'related' => 'Anomaly\PostsModule\Type\TypeModel',
            ],
        ],
    ];
}
