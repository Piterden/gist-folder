<?php namespace Defr\ExporterExtension\Listener;

use Anomaly\Streams\Platform\Ui\ControlPanel\Component\Section\Event\GatherSections;

class ModifyControlPanel
{

    /**
     * Handle the command
     *
     * @param GatherSections $event The event
     */
    public function handle(GatherSections $event)
    {
        $segments = app('request')->segments();

        if (array_get($segments, 0) !== 'admin')
        {
            return;
        }

        /* @var ControlPanelBuilder $builder */
        $builder   = $event->getBuilder();
        $sections  = $builder->getSections();
        $namespace = array_get($segments, 1);

        if (($name = array_get(
            $segments,
            2,
            array_get(array_reverse($segments), 0)
        )) === 'fields')
        {
            $name = array_get(array_reverse($segments), 0);

            $buttons = array_merge(
                array_get($sections, "{$name}.buttons", []),
                [
                    'export' => [
                        'text' => trans('streams::button.export') . " {$namespace} fields",
                        'href' => "admin/{$namespace}/fields/export",
                    ],
                ]
            );

            array_set($sections, "{$name}.buttons", $buttons);
        }

        if (count($segments) > 2 && in_array('fields', $segments))
        {
        }

        $builder->setSections($sections);
    }
}
