<?php

namespace Defr\ExporterExtension\Test\Feature;

class ExporterExtensionTest extends \TestCase
{

    public function testHome()
    {
        // $this->visit('/');
    }
}
