<?php namespace Defr\ExporterExtension\Field\Command;

use Anomaly\Streams\Platform\Addon\Addon;
use Anomaly\Streams\Platform\Field\Contract\FieldInterface;
use Anomaly\Streams\Platform\Field\Contract\FieldRepositoryInterface;
use Illuminate\Filesystem\Filesystem;

/**
 * Class for generate fields migration.
 */
class GenerateFieldsMigration
{

    /**
     * Addon
     *
     * @var Addon
     */
    protected $addon;

    /**
     * Addon namespace
     *
     * @var string
     */
    protected $namespace;

    /**
     * Create an instance of GenerateFieldsMigration class
     *
     * @param string $namespace The namespace
     */
    public function __construct(Addon $addon, string $namespace)
    {
        $this->namespace = $namespace;
        $this->addon     = $addon;
    }

    /**
     * Handle the command
     *
     * @param FieldRepositoryInterface $fields The fields
     * @param Filesystem               $files  The files
     */
    public function handle(FieldRepositoryInterface $fields, Filesystem $files)
    {
        $migration = $fields->findAllByNamespace($this->namespace)->map(
            function (FieldInterface $field)
            {
                $data = array_except($field->getAttributes(), ['slug', 'id']);

                array_set($data, 'config', unserialize(array_get($data, 'config')));

                $str = "        '{$field->getAttribute('slug')}' => [\n";

                foreach ($data as $key => $value)
                {
                    if (is_string($value))
                    {
                        $str .= "            '{$key}' => '{$value}',\n";
                    }

                    if (is_array($value))
                    {
                        $str .= "            '{$key}' => [\n";

                        foreach ($value as $k => $v)
                        {
                            $str .= "                '{$k}' => '{$v}',\n";
                        }

                        $str .= "            ],\n";
                    }
                }

                $str .= "        ],\n";

                return $str;
            }
        )->all();

        $path = __DIR__ . '/../../../resources/generated';

        if (!$files->exists($path))
        {
            $files->makeDirectory($path);
        }

        $vendor = $this->addon->getVendor();
        $type   = $this->addon->getType();
        $slug   = $this->addon->getSlug();

        if ($files->put(
            $path . "/{$vendor}.{$type}.{$slug}__create_{$slug}_fields.php",
            "<?php\n\n"
            . "use Anomaly\Streams\Platform\Database\Migration\Migration;\n\n"
            . 'class ' . ucfirst($vendor) . ucfirst($type) . ucfirst($slug)
            . 'Create' . ucfirst($slug) . "Fields extends Migration\n{\n\n    "
            . "/**\n     * The addon fields.\n     *\n     * @var array\n     "
            . "*/\n    protected \$fields = [\n" . implode('', $migration)
            . "    ];\n}\n"
        ))
        {
            return true;
        }

        return false;
    }
}
