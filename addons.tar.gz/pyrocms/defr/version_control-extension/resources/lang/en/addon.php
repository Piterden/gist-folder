<?php

return [
    'title'       => 'Version Control',
    'name'        => 'Version Control Extension',
    'description' => 'Versionizing system for DB entries.',
];
