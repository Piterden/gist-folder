<?php namespace Defr\VersionControlExtension\Revision;

use Anomaly\Streams\Platform\Entry\EntryObserver;

class RevisionObserver extends EntryObserver
{

}
