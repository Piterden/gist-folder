<?php

return [
    'namespace' => [
        'name' => 'Namespace',
    ],
    'slug'      => [
        'name' => 'Slug',
    ],
    'parent'    => [
        'name' => 'Parent entry id',
    ],
    'data'      => [
        'name' => 'Data',
    ],
];
