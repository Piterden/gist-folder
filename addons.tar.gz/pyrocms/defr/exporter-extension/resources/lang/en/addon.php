<?php

return [
    'title'       => 'Exporter',
    'name'        => 'Exporter Extension',
    'description' => ''
];
