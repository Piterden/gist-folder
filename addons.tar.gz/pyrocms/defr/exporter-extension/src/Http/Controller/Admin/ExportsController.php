<?php namespace Defr\ExporterExtension\Http\Controller\Admin;

use Anomaly\Streams\Platform\Addon\Command\GetAddon;
use Anomaly\Streams\Platform\Http\Controller\AdminController;
use Defr\ExporterExtension\Field\Command\GenerateFieldsMigration;

class ExportsController extends AdminController
{

    /**
     * Export fields to the migration
     *
     * @param  FieldRepositoryInterface $fields    The fields
     * @param  Filesystem               $files     The filesystem
     * @param  string                   $namespace The namespace
     * @return Response
     */
    public function export($namespace)
    {
        /* @var Addon $addon */
        $addon = $this->dispatch(new GetAddon($namespace));

        if ($this->dispatch(new GenerateFieldsMigration($addon, $namespace)))
        {
            $this->messages->success('defr.extension.exporter::message.migration_created');

            return back();
        }

        $this->messages->error('defr.extension.exporter::message.migration_create_failed');

        return back();
    }
}
