<?php namespace Defr\VersionControlExtension\Revision\Form\Handler;

class Entry
{

    public function handle()
    {

    }
}
