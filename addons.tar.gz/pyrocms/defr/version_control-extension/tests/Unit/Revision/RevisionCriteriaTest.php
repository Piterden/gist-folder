<?php

namespace Defr\VersionControlExtension\Test\Unit\Revision;

class RevisionCriteriaTest extends \TestCase
{

}
