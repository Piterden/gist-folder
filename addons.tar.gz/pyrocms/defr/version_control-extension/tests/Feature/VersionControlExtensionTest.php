<?php

namespace Defr\VersionControlExtension\Test\Feature;

class VersionControlExtensionTest extends \TestCase
{

    public function testHome()
    {
        // $this->visit('/');
    }
}
