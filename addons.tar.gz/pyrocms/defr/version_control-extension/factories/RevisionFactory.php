<?php

$factory->define(
    Defr\VersionControlExtension\Revision\RevisionModel::class,
    function (Faker\Generator $faker) {
        return [
            //'title' => $faker->words(2),
        ];
    }
);
