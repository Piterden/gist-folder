<?php

return [
    'revisions'        => 'Revisions',
    'show_revision'    => 'Show Revision',
    'restore_revision' => 'Restore Revision',
];
