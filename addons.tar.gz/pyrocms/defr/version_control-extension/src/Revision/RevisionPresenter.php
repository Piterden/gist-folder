<?php namespace Defr\VersionControlExtension\Revision;

use Anomaly\Streams\Platform\Entry\EntryPresenter;

class RevisionPresenter extends EntryPresenter
{

}
