<?php namespace Defr\VersionControlExtension\Revision;

use Anomaly\Streams\Platform\Entry\EntryRouter;

class RevisionRouter extends EntryRouter
{

}
