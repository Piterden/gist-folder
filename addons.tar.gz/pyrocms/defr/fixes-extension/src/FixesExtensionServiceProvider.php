<?php namespace Defr\FixesExtension;

use Anomaly\Streams\Platform\Addon\AddonServiceProvider;

class FixesExtensionServiceProvider extends AddonServiceProvider
{

    /**
     * Addon overrides
     *
     * @var array|null
     */
    protected $overrides = [
        'streams::tree.macro' => 'defr.extension.fixes::tree.macro',
    ];

    /**
     * Addon assets
     *
     * @var array|null
     */
    protected $assets = [
        'streams::js/tree/tree.js' => 'defr.extension.fixes::js/tree/tree.js',
    ];
}
