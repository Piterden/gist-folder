<?php namespace Defr\VersionControlExtension\Revision;

use Anomaly\Streams\Platform\Entry\EntryCollection;

class RevisionCollection extends EntryCollection
{

}
