<?php namespace Defr\ExporterModule\Field\Table;

class FieldTableBuilder extends \Anomaly\Streams\Platform\Field\Table\FieldTableBuilder
{

}
