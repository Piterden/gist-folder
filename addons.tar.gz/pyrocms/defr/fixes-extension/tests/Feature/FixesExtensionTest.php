<?php

namespace Defr\FixesExtension\Test\Feature;

class FixesExtensionTest extends \TestCase
{

    public function testHome()
    {
        // $this->visit('/');
    }
}
